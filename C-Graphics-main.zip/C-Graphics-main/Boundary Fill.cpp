#include<iostream>
#include<graphics.h>
#include<dos.h>
using namespace std;
void boundaryfill(int x,int y,int f_color,int b_color)
{
if(getpixel(x,y)!=b_color && getpixel(x,y)!=f_color)
{

putpixel(x,y,f_color);
boundaryfill(x+1,y,f_color,b_color);
boundaryfill(x,y+1,f_color,b_color);
boundaryfill(x-1,y,f_color,b_color);
boundaryfill(x,y-1,f_color,b_color);
delay(1);
}
}
//getpixel(x,y) gives the color of specified pixel

int main()
{
int gm,gd=DETECT,radius;
int x,y;
cout<<"Enter x and y positions for circle\n";
cin>>x>>y;
cout<<"Enter radius of circle\n";
cin>>radius;
initgraph(&gd,&gm,"c:\\turboc3\\bgi");
circle(x,y,radius);
boundaryfill(x,y,8,15);

closegraph();
return 0;
}

